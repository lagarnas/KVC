import Foundation

/*
 KVC - это форма кодирования, которая позволяет получать доступ к свойствам объекта косвенно,
 используя строки для доступа к ним вместо методов доступа свойства или вместо прямого доступа
 к переменным. Чтобы включить такой механизм, классы должны соответствовать протоколу
 NSKeyValueCoding.

 Кодирование «ключ-значение» - механизм, с помощью которого вы можете получить доступ к
 свойствам объекта косвенно по имени или ключу.
 Используется в CoreData
 */

// MARK: - Class User

final class User: NSObject {
    @objc private var name = String()
    @objc var age = 0
    @objc var nicknames = ["The best man", "123trololo"]
}

// MARK: - Extension class

extension User {
    var nameValue: String {
        let name = value(forKey: #keyPath(User.name)) as? String ?? ""
        return name
    }
}


// MARK: - Сlass instance

let user = User()


// MARK: - Usual setting value

//user.name = "Jack"


// MARK: - Setting values using KVC

// setValue

user.setValue("Lola", forKey: "name")


// setValue using #keyPath

//user.setValue("Kristy", forKey: #keyPath(User.nameValue))


// setValuesForKeys

user.setValuesForKeys(["name" : "Peter",
                       "age": 6])


var mutableArray = user.mutableArrayValue(forKey: #keyPath(User.nicknames))
mutableArray.add("La la la")


// MARK: - Prints

print(user.nameValue)
print(user.age)
print(user.nicknames)
